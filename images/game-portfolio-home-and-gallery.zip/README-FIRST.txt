HOW TO UPDATE YOUR EXISTING GITHUB PAGES WEBSITE

1. Back up your existing index.html and images.html before replacing them.
2. Copy index.html, images.html, and portfolio-updates.css to the TOP level of your existing game-developer-portfolio folder.
3. Copy the entire images folder next to those files (not nested inside another folder).
4. KEEP your current style.css, about.html, projects.html, and contact.html. Do not overwrite them.
5. Open index.html and images.html in your browser to confirm that images load.
6. Upload/commit the two HTML files, the new CSS file, and all six images in the images folder to GitHub.

IMPORTANT: Image filenames must match exactly; GitHub Pages is case-sensitive.
